import React, {useState} from 'react';
import '../../styles/CreateBookForm.css';

const CreateBookForm = ({onSubmit, onCancel}) => {
  // Use the props to set the initial values of the form fields
    
  const [titre, setTitre] = useState('');
  const [auteur, setAuteur] = useState('');
  const [anneePublication, setAnneePublication] = useState('');
  const [genre, setGenre] = useState('');
  const [resume, setResume] = useState('');

    const handleSubmit = (event) => {
        event.preventDefault();
        onSubmit(titre, auteur,anneePublication,genre,resume)
    }

    const handleCancel = (event) => {
        event.preventDefault()
        onCancel()
    }
    
    return (
    <form onSubmit={handleSubmit} className='form-container'>
        <h2>
            Create Book:
        </h2>
        <label>
        Titre:
        <input 
            type="text" 
            id="titre"
            value={titre}
            onChange={(e) => setTitre(e.target.value)}
        />
        </label>
        <label>
        Auteur:
        <input 
            type="text" 
            id="auteur"
            value={auteur}
            onChange={(e) => setAuteur(e.target.value)}
        />
        </label>
        <label>
        Année de publication:
        <input 
            type="text" 
            id="titre"
            value={anneePublication}
            onChange={(e) => setAnneePublication(e.target.value)}
        />
        </label>
        <label>
        Genre:
        <input 
            type="text" 
            id="genre"
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
        />
        </label>
        <label>
        Résumé:
        <textarea 
            value={resume} 
            onChange={(e)=> setResume(e.target.value)}
            id="resume">
        </textarea>
        </label>
        <div className='buttonContainer'>
            <button type="submit">Submit</button>
            <button type="submit" className='cancelButton' onClick={handleCancel}>cancel</button>
        </div>
    </form>
    );
};

export default CreateBookForm;
