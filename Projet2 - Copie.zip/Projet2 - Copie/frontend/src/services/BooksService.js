async function getBooks() {
    try {
        const jwtToken = localStorage.getItem("jwtToken")
        const response = await fetch('http://localhost:5000/api/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({jwtToken})

        });
        if (response.ok) {
            const data = await response.json();
            return data;
        } else {
            const errorData = await response.json();
            console.error('Fetching data failed', errorData);
            return [];
        }
    } catch (error) {
        console.error('Error:', error);
        return   [];
    }
}

async function createBook(titre, auteur, anneePublication, genre, resume) {
    try {
        const jwtToken = localStorage.getItem('jwtToken');
        anneePublication = parseInt(anneePublication, 10);
        const response = await fetch('http://localhost:5000/api/book', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ titre, auteur, anneePublication, genre, resume,jwtToken })
        });

        if (response.ok) {
            const data = await response.json();
            console.log('Book created with success');
            return data;
        } else {
            const errorData = await response.json();
            console.error('Book creation failed', errorData.error);
            return { success: false, error: errorData.error };
        }
    } catch (error) {
        console.error('Error:', error);
        return { success: false, error: 'Network error' };
    }
}

async function updateBook(id, titre, auteur, anneePublication, genre, resume) {
    try {
        const jwtToken = localStorage.getItem("jwtToken")
        anneePublication = parseInt(anneePublication, 10);
        console.log("updatebook id:", id)
        const response = await fetch(`http://localhost:5000/api/books/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ titre, auteur, anneePublication, genre, resume, jwtToken })
        });

        if (response) {
            const data = await response.json();
            console.log('Book updated with success');
            return data;
        } else {
            const errorData = await response.json();
            console.error('Book update failed', errorData.error);
            return { success: false, error: errorData.error };
        }
    } catch (error) {
        console.error('Error:', error);
        return { success: false, error: 'Network error' };
    }
}

async function deleteBook(id) {
    try {
        const jwtToken = localStorage.getItem("jwtToken")
        const response = await fetch(`http://localhost:5000/api/books/${id}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({jwtToken})
        });
        if (response.ok) {
            console.log('Service: Book deleted successfully');
            return { success: true };
        } else {
            const errorData = await response.json();
            console.error('Error deleting book', errorData);
            return { success: false, error: errorData.error };
        }
    } catch (error) {
        console.error('Error:', error);
        return { success: false, error: 'Network error' };
    }
}

async function getBook(id){
    try {
        const jwtToken = localStorage.getItem("jwtToken")
        const response = await fetch(`http://localhost:5000/api/books/${id}`,{
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({jwtToken})
        })
        if(response.ok){
            const data = response.json()
            return data
        }else{
            console.error("error fetching book")
        }
    } catch (error) {
        console.error("server error")
    }
}

export default { getBooks, createBook, updateBook, deleteBook, getBook };
