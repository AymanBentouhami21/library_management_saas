

async function createPret(idLivre,dateRetour){
    try {
        const jwtToken = localStorage.getItem("jwtToken")
        const response = await fetch('http://localhost:5000/api/prets',{
            method:"POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({dateRetour,idLivre,jwtToken})
        })
        if (response.ok){
            const data = response.json()
            return data
        }else{
            const errData = response.json()
            console.error("Error fetching CreatePret",errData);
            return []
        }
    } catch (error) {
        console.error("Server Error:", error)
        return []
    }
};

async function getPretByUserId(){
    
    try {
        const jwtToken = localStorage.getItem("jwtToken")
        const response = await fetch("http://localhost:5000/api/prets/byUserId",{
            method: "POST",
            headers: {"Content-Type" : "application/json"},
            body: JSON.stringify({jwtToken})
        })
        if(response.ok){
            const data =response.json()
            console.log("data")
            console.log(data)
            return data
        }else{
            const errData = response.json()
            console.error("Error fetching CreatePret",errData);
            return []
        }
    } catch (error) {
        console.error("Server Error:", error)
        return []
    }
}

async function deletePretByBookId(idLivre){
    try {
        const jwtToken = localStorage.getItem("jwtToken");
        console.log("jwtToken",jwtToken)
        const response = await fetch('http://localhost:5000/api/prets/deleteByBookId',{
            method:'DELETE',
            headers : {"Content-type":"application/json"},
            body:JSON.stringify({jwtToken,idLivre})
        })
        if(response.ok){
            const data =response.json()
            return data
        }else{
            const errData = response.json()
            console.error("Error fetching CreatePret",errData);
            return []
        }
    } catch (error) {
        console.error("Server Error:", error)
        return []
    }
}

export default {createPret, getPretByUserId,deletePretByBookId};
