import React, { useState } from 'react';
import '../../styles/LoginForm.css'
const LoginForm = ({ onSubmit }) => {
 
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    onSubmit(email, password);
  };

  return (
    <div className='login-form-container'>
      
      <form onSubmit={handleSubmit} className='login-form'>
      <h2>
        Login
      </h2>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="text"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
      </div>
      <button type="submit">Login</button>
    </form>
    </div>
    
  );
};

export default LoginForm;
