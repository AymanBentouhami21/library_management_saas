// utilisateur.routes.js

const express = require('express');
const router = express.Router();
const { createUser, loginUser, getUserById, updateUser, deleteUser, getAllUsers} = require('../controllers/utilisateur.controller');

// Define routes for Utilisateur (User) entity
router.post('/api/users',getAllUsers)
router.post('/api/users/register', createUser);
router.post('/api/users/login', loginUser);
router.post('/api/users/:id', getUserById);
router.put('/api/users/:id', updateUser);
router.delete('/api/users/:id', deleteUser);

module.exports = router;
