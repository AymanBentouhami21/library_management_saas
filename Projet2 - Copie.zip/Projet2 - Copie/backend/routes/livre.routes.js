//GET /api/books : Récupérer la liste de tous les livres.
//GET /api/books/:id : Récupérer les informations d'un livre par son ID.
//POST /api/books : Ajouter un nouveau livre.
//PUT /api/books/:id : Mettre à jour les informations d'un livre.
//DELETE /api/books/:id : Supprimer un livre.

const express = require("express")
const router = express.Router();
const {getAllBooks, getBookById, createBook, updateBookById, deleteBook} = require("../controllers/books.controller")

router.post("/api/books", getAllBooks);
router.post("/api/books/:id", getBookById);
router.post("/api/book", createBook);
router.put("/api/books/:id", updateBookById);
router.delete("/api/books/:id", deleteBook)

module.exports = router;