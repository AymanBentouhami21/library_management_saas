import React from 'react';
import Table from './Table';
import '../../styles/Table.css';

const Board = ({ data, onUpdate,onDelete, toggleUpdateForm, onPretre}) => {
  
  const convertBooleanToString = (value) => {
    return typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value;
  }

  const convertBooleansToString = (data) => {
    const convertValue = (value) => {
      if (typeof value === 'boolean') {
        return value ? 'Yes' : 'No';
      } else if (Array.isArray(value)) {
        return value.map(convertValue);
      } else if (typeof value === 'object' && value !== null) {
        const convertedObject = {};
        for (const key in value) {
          if (Object.prototype.hasOwnProperty.call(value, key)) {
            convertedObject[key] = convertValue(value[key]);
          }
        }
        return convertedObject;
      } else {
        return value;
      }
    };
  
    return data.map(convertValue);
  };

  const cv_data = convertBooleansToString(data);
  

  return (
    <div>
      <Table data={cv_data} onUpdate={onUpdate} onDelete={onDelete} onPretre={onPretre}/>
    </div>
  );
};

export default Board;
