const Livre = require('../models/livre.model')
const bcrypt = require('bcrypt')
const authenticate = require('../middleware/authenticate')

async function createBook(req, res) {
    try {
      const { titre, auteur, anneePublication, genre, resume, disponible, jwtToken } = req.body;
  
      // Check authorization using isAuthorized
      const {isAuthorized,message} = await authenticate(jwtToken, "administrateur");
        
      if (isAuthorized === false) {
        return res.status(403).json({ message: message });
      }
  
      // Create book logic (assuming Livre.create is a model creation function)
      const newBook = await Livre.create({ titre, auteur, anneePublication, genre, resume, disponible });
  
      // Respond with created book data
      res.status(201).json(newBook);
    } catch (error) {
      console.error("Error creating book:", error);
      res.status(500).json({ error: 'An internal server error occured' });
    }
  }

async function getAllBooks(req,res){
    try {
        const {jwtToken} = req.body
        const {isAuthorized,message} = await authenticate(jwtToken, "utilisateur");
        if (isAuthorized === false) {
            return res.status(403).json({ message: message });
          }
        const books = await Livre.findAll();
        res.status(200).json(books);
    } catch (error) {
        console.error("error fetching books:",error);
        res.status(500).json({error:"An internal server error occured."})
    }
}

async function updateBookById(req,res){
    try {
        const bookId = req.params.id;
        const {titre, auteur, anneePublication, genre, resume, disponible, jwtToken} = req.body;
        
        const {isAuthorized,message} = await authenticate(jwtToken, "administrateur");
        
        if (isAuthorized === false) {
            return res.status(403).json({ message: message });
          }
        
        const book = await Livre.findByPk(bookId);
        

        if(!book){
            return res.status(404).json({error:"Book not found"});
        }
        console.log(bookId)
        book.titre = titre;
        book.auteur = auteur;
        book.anneePublication = anneePublication;
        book.genre = genre;
        book.resume = resume;
        book.disponible = disponible;        

        await book.save();
        res.status(200).json(book);
    } catch (error) {
        console.error("Error updating book:", error);
        res.status(500).json({error:'An internal server error occured'})
    }
}

async function getBookById(req,res){
    try {
        const bookId = req.params.id;

        const {jwtToken} = req.body
        const {isAuthorized,message} = await authenticate(jwtToken,"utilisateur")

        if (isAuthorized === false) {
            return res.status(403).json({ message: message });
          }

        const book = await Livre.findByPk(bookId);
        
        if(!book){
            return res.status(404).json({error:"Book not found"});
        }
        res.status(200).json(book)
        
        
    } catch (error) {
        console.error("Error fetching book:", error);
        res.status(500).json({error:'An internal server error occured'})
    }
}

async function deleteBook(req,res){
    try {
        const bookId = req.params.id;
        const {jwtToken} = req.body
        const {isAuthorized,message} = await authenticate(jwtToken,"administrateur")

        if (isAuthorized === false) {
            return res.status(403).json({ message: message });
          }

        const book = await Livre.findByPk(bookId)

        if(!book){
            res.status(404).json({error: "Book not found"});
            return;
        }else{
            await book.destroy();
            res.status(200).json({message:"Book deleted succesfully"});
        }

    } catch (error) {
        console.error("Error deleting user:", error);
        res.status(500)
    }
}

module.exports = {getAllBooks, getBookById, createBook, updateBookById, deleteBook}