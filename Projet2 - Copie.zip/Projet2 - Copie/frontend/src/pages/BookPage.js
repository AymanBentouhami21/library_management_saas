import React, { useState, useEffect } from 'react';
import Navbar from '../components/BookComponents/NavBar';
import BooksNavBar from "../components/BookComponents/BooksNavBar";
import Board from "../components/BookComponents/Board";
import CreateBookForm from "../components/BookComponents/CreateBookForm";
import UpdateBookForm from '../components/BookComponents/UpdateBookForm';
import CreatePretForm from "../components/LoanComponents/CreatePretreForm"
import '../styles/BookPage.css';
import BooksService from '../services/BooksService';
import LoansServices from '../services/LoansServices';

const BookPage = () => {
  const [selectedFilter, setSelectedFilter] = useState('Author');
  const [books, setBooks] = useState([]);
  const [loanedBooks, setLoanedBooks] = useState([])
  const [loading, setLoading] = useState(true);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showUpdateForm, setShowUpdateForm] = useState(false);
  const [showPretreForm, setShowPretreForm] = useState(false)
  const [current_data, setCurrentData] = useState({});
  const [bookToLoan, setBookToLoan] = useState(null);
  
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const pretResponse = await LoansServices.getPretByUserId()
        const bookResponse = await BooksService.getBooks(selectedFilter);

        setBooks(bookResponse);
        setLoanedBooks(pretResponse)
        console.log(pretResponse)
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, [selectedFilter]);

  const handleFilterChange = (filter) => {
    setSelectedFilter(filter);
  };

  const toggleCreateForm = () => {
    setShowCreateForm(!showCreateForm);
  };

  const toggleUpdateForm = () => {
    setShowUpdateForm(!showUpdateForm)

  };

  const togglePretreForm = () =>{
    setShowPretreForm(!showPretreForm)
  };

  const handleCreateBookForm = async (titre, auteur, anneePublication, genre, resume) => {
    try {
      const result = await BooksService.createBook(titre, auteur, anneePublication, genre, resume);
      const {id} = result
      if(id !== null){
        setBooks([...books, result]);
        setShowCreateForm(false);
        console.log('Book stored with success');
      }else {
        console.error('Storing failed');
        setShowCreateForm(false);
      }
    }
    catch (error) {
      console.error('Server error:', error);
    }
  };
  
  const handleUpdateBookForm = async (id, titre, auteur, anneePublication, genre, resume) => {
    try {
      const response = await BooksService.updateBook(id, titre, auteur, anneePublication, genre, resume);
      if (response) {
        setBooks(
          books.map((book) => (book.id === id ? response : book)) // Update only the matching book
        );
        setShowUpdateForm(false);
        console.log("Book updated successfully");
      } else {
        console.error('Book update failed');
      }
    } catch (error) {
      console.error("Server error:", error);
    }
  };


  const handleCreatePretForm = async (dateRetour) => {
    try {
      if (!bookToLoan) {
        console.error('Please select a book to loan');
        return; // Prevent creating a loan without a selected book
      }

      const response = await LoansServices.createPret(bookToLoan, dateRetour);
      console.log("response",response)
      if (response) {
        // Update books state to reflect the loan (optional)
        // You might need to fetch updated book data or adjust the UI
        console.log('Loan created successfully');
        const pretResponse = await LoansServices.getPretByUserId()
        const bookResponse = await BooksService.getBooks(selectedFilter);
        setLoanedBooks(pretResponse)
        setBooks(bookResponse);
      } else {
        console.error('Error creating loan');
      }
    } catch (error) {
      console.error('Server error:', error);
    } finally {
      // Clear selected book and close loan form
      setBookToLoan(null);
      setShowPretreForm(false);
    }
  };

  const onDelete = async (book) => {
    try {
      const { id } = book;
      console.log(id);
      const response = await BooksService.deleteBook(id);
      if (response.success) {
        setBooks(books.filter((b) => b.id !== id));
        console.log('Deleted book successfully');
      } else {
        console.error('Error deleting book');
      }
    } catch (error) {
      console.error('Server error:', error);
    }
  };

  const onUpdate = async (book) => {  
    try {
      const {id} = book
      const response = await BooksService.getBook(id);
      setCurrentData(response)
      await toggleUpdateForm();

    } catch (error) {
      console.error('Error updating book:', error);
    }
  };

  const onPretre = async (book) => {
    try {
      console.log("pret")
      const { id } = book;
      setBookToLoan(id);
      await togglePretreForm();
      
     
    } catch (error) {
      console.error('Error selecting book for loan:', error);
    }
  };

  const onRendre = async (book) => {
    try {
      const { id } = book;
      const idLivre = id
      console.log(idLivre)
      const response = await LoansServices.deletePretByBookId(idLivre)
      if (response) {
        const pretResponse = await LoansServices.getPretByUserId()
        const bookResponse = await BooksService.getBooks(selectedFilter);
        setLoanedBooks(pretResponse)
        setBooks(bookResponse)
        console.log(response)
      }
      
    } catch (error) {
      console.error("Error returning book")
    }

  }

  const cancelCreateBookForm = async() => {
    setShowCreateForm(false)
  }
  const cancelUpdateBookForm = async() => {
    setShowUpdateForm(false)
  }
  return (
    <div className="container">
      
      <Navbar />
  
      <main className="main-content">
        <div className='container2'>
          <h2>Book Page</h2>
          <button onClick={toggleCreateForm}>Create</button>
        </div>
        <div className='side-by-side'>
          <BooksNavBar handleFilterChange={handleFilterChange} />
          {loading ? <p>Loading...</p> : <Board bookData={books} loanedBooks={loanedBooks} onUpdate={onUpdate} onDelete={onDelete} toggleUpdateForm={toggleUpdateForm} onPretre={onPretre} onRendre={onRendre}/>}
        </div>
        {showCreateForm && <div className="overlay"><CreateBookForm onSubmit={handleCreateBookForm} onCancel={cancelCreateBookForm} /></div>}
        {showUpdateForm && <div className='overlay'><UpdateBookForm onSubmit={handleUpdateBookForm} current_data={current_data} onCancel={cancelUpdateBookForm}></UpdateBookForm></div>}
        {showPretreForm && <div className='overlay'><CreatePretForm onSubmit={handleCreatePretForm}></CreatePretForm></div>}
      </main>
    </div>
  );
};


export default BookPage;
