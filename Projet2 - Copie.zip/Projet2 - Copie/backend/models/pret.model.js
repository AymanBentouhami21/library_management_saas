// MODELS/pret.model.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db.config');
const Utilisateur = require('./utilisateur.model');
const Livre = require('./livre.model');

const Pret = sequelize.define('Pret', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  dateEmprunt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  dateRetour: {
    type: DataTypes.DATE
  },
  createdAt: {
    type: DataTypes.DATE,
    field: 'dateRetour' // Map createdAt to 'dateDeRetour'
  }
},
{
  timestamps : false, 
});

// Define associations
Pret.belongsTo(Utilisateur, { foreignKey: 'idUtilisateur' });
Pret.belongsTo(Livre, { foreignKey: 'idLivre' });

module.exports = Pret;
