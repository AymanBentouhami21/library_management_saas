import React, { useState } from 'react';
import '../../styles/CreateBookForm.css';
const UpdateUserForm = ({ onSubmit, current_data , onCancel}) => {
  console.log("Update User form:", current_data); // Optional logging

  const initialValues = {
    nom: current_data?.nom || "",
    email: current_data?.email || "",
    motDePasse: current_data?.motDePasse || "",
    role: current_data?.role || "",
  };

  const [formData, setFormData] = useState(initialValues);

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.id]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    onSubmit(current_data.id, formData.nom, formData.email, formData.motDePasse, formData.role);
  };
  const handleCancel = (event) => {
    event.preventDefault()
    onCancel()
  };

  return (
    <form onSubmit={handleSubmit} className='form-container'>
      <h2>
        Update User:
      </h2>
      <label>
        Nom:
        <input type="text" id="nom" value={formData.nom} onChange={handleChange} />
      </label>
      <label>
        Email:
        <input type="text" id="email" value={formData.email} onChange={handleChange} />
      </label>
      <label>
        motDePasse:
        <input type="text" id="motDePasse" value={formData.motDePasse} onChange={handleChange} />
      </label>
      <label>
        Role:
        <input type="text" id="role" value={formData.role} onChange={handleChange} />
      </label>
      <div className='buttonContainer'>
            <button type="submit">Submit</button>
            <button type="submit" className='cancelButton' onClick={handleCancel}>cancel</button>
        </div>
    </form>
  );
};

export default UpdateUserForm;
