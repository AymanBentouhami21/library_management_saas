import React from 'react';

const Table = ({ bookData, onUpdate, onDelete, onPretre, onRendre }) => {

  if (!bookData || bookData.length === 0) {
    return <div>No data available</div>;
  }

  const headers = Array.from(new Set(bookData.flatMap(Object.keys))).filter((header)=> header !=='disponible' && header !== 'pretre');

  return (
    <table>
      <thead>
        <tr>
          {headers.map((header) => (
            <th key={header}>{header}</th>
          ))}
          <th>Actions</th> {/* Add this separate header for buttons */}
        </tr>
      </thead>
      <tbody>
        {bookData.map((row, index) => (
          <tr key={index}>
            {headers.filter((header) => header !== 'disponible' || header !== 'pretre').map((header) => (
              <td key={header}>{row[header] || 'N/A'}</td>
            ))}
            <td className="actions"> {/* Use a single parent element for buttons */}
              {row.disponible === 'Yes' ? (
                <button onClick={() => onPretre(row)} className='preterButton'>Prêter</button>
              ) : row.pretre === 'Yes' ? (
                <button onClick={() => onRendre(row)} className='rendreButton'>Rendre</button>
              ) : (
                <button disabled className='indisponibleButton'>Indisponible</button>
              )}
              <button onClick={() => onUpdate(row)} className='updateButton'></button>
              <button onClick={() => onDelete(row)} className='deleteButton'></button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
