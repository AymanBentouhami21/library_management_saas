import React, {useState} from 'react';
import '../../styles/CreateBookForm.css';
const CreateUserForm = ({onSubmit, onCancel}) => {
  // Use the props to set the initial values of the form fields
    
  const [nom, setNom] = useState('');
  const [email, setEmail] = useState('');
  const [motDePasse, setMotDePasse] = useState('');
  const [role, setRole] = useState('');
  

    const handleSubmit = (event) => {
        event.preventDefault();
        onSubmit(nom,email,motDePasse,role)
    }

    const handleCancel = (event) => {
        event.preventDefault()
        onCancel()
    }
    
    return (
    <form onSubmit={handleSubmit} className='form-container'>
        <h2>
            Create User:
        </h2>
        <label>
        Nom:
        <input 
            type="text" 
            id="nom"
            value={nom}
            onChange={(e) => setNom(e.target.value)}
        />
        </label>
        <label>
        Email:
        <input 
            type="text" 
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
        />
        </label>
        <label>
        Mot de passe:
        <input 
            type="text" 
            id="motDePasse"
            value={motDePasse}
            onChange={(e) => setMotDePasse(e.target.value)}
        />
        </label>
        <label>
        Role:
        <input 
            type="text" 
            id="role"
            value={role}
            onChange={(e) => setRole(e.target.value)}
        />
        </label>
        <label>
        </label>
        <div className='buttonContainer'>
        <button type="submit">Submit</button>
        <button type="submit" className='cancelButton' onClick={handleCancel}>cancel</button>
        </div>
    </form>
    );
};

export default CreateUserForm;
