// src/App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import BookPage from './pages/BookPage';
import UserPage from './pages/UserPage'
// Import your HomePage component

const App = () => { 
   // Check for token in local storage

  return (
    <Router>
      <Routes>
        {/* Default route */}
        <Route path="/" element={<Navigate to="/login" />} />
        {/* Public routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/home" element={localStorage.getItem('jwtToken') ? <HomePage />:<p>please log in to homepage</p>} />
        <Route path="/book" element={localStorage.getItem('jwtToken') ? <BookPage />:<p>please log in to homepage</p>} />
        <Route path="/user" element={localStorage.getItem('jwtToken') ? <UserPage />:<p>please log in to homepage</p>} />        {/* Add more routes as needed */}
      </Routes>
    </Router>
  );
};

export default App;
