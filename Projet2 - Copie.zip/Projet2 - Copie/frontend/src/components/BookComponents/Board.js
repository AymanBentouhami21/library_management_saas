import React from 'react';
import Table from './Table';
import '../../styles/Table.css';

const Board = ({ bookData, loanedBooks, onUpdate,onDelete, onPretre, onRendre}) => {
  
  

  const convertBooleansToString = (data) => {
    const convertValue = (value) => {
      if (typeof value === 'boolean') {
        return value ? 'Yes' : 'No';
      } else if (Array.isArray(value)) {
        return value.map(convertValue);
      } else if (typeof value === 'object' && value !== null) {
        const convertedObject = {};
        for (const key in value) {
          if (Object.prototype.hasOwnProperty.call(value, key)) {
            convertedObject[key] = convertValue(value[key]);
          }
        }
        return convertedObject;
      } else {
        return value;
      }
    };
  
    return data.map(convertValue);
  };

  function addPretreAttribute(cv_data, loanedBooks) {
    
    const loanedBookIdSet = new Set(loanedBooks.map(pret => pret.idLivre));
    for (const bookEntry of cv_data) {
      const bookId = bookEntry.id;
      const isPretre = loanedBookIdSet.has(bookId); 
      
      
      bookEntry.pretre = isPretre ? 'Yes' : 'No';
    }
  }

  const cv_data = convertBooleansToString(bookData);
  
  addPretreAttribute(cv_data,loanedBooks)





  return (
    <div>
      <Table bookData={cv_data} onUpdate={onUpdate} onDelete={onDelete} onPretre={onPretre} onRendre={onRendre}/>
    </div>
  );
};

export default Board;
