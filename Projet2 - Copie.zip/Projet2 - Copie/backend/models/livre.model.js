// MODELS/livre.model.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db.config');

const Livre = sequelize.define('Livre', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  titre: {
    type: DataTypes.STRING,
    allowNull: false
  },
  auteur: {
    type: DataTypes.STRING,
    allowNull: false
  },
  anneePublication: {
    type: DataTypes.INTEGER
  },
  genre: {
    type: DataTypes.STRING
  },
  resume: {
    type: DataTypes.STRING
  },
  disponible: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
},
{
  timestamps : false, 
}
);

module.exports = Livre;
