import React from 'react';
import '../../styles/Table.css';
const Table = ({ data, onUpdate, onDelete, onPretre }) => {
  
  if (!data || data.length === 0) {
    return <div>No data available</div>;
  }

  // Extract headers from the first row, considering the possibility of missing headers
  const headers = Array.from(new Set(data.flatMap(Object.keys)));

  
  return (
    <table>
      <thead>
        <tr>
          {headers.map((header) => (
            <th key={header}>{header}</th>
          ))}
          <th></th>
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => (
          <tr key={index}>
             {headers.map((header) => (
              <td key={header}>{row[header] || 'N/A'}</td>
            ))}
            
            
            <td>
              <button onClick={() => onUpdate(row)} className='updateButton'></button>
              <button onClick={() =>onDelete(row)} className='deleteButton'></button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
