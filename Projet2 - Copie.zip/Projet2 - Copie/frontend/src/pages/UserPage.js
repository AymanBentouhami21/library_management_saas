import React, { useState, useEffect } from 'react';

import Navbar from '../components/BookComponents/NavBar';
import UsersNavBar from "../components/UserComponents/UsersNavBar";
import Board from "../components/UserComponents/Board";
import CreateUserForm from "../components/UserComponents/CreateUserForm";
import UpdateUserForm from '../components/UserComponents/UpdateUserForm';
import '../styles/BookPage.css';
import UsersService from '../services/UsersService';

const UserPage = ()=>{
    const [selectedFilter, setSelectedFilter] = useState('nom');
    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showCreateForm, setShowCreateForm] = useState(false);
    const [showUpdateForm, setShowUpdateForm] = useState(false);
    const [current_data, setCurrentData] = useState({});
    
    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await UsersService.getUsers(selectedFilter);
          setBooks(response);
          setLoading(false);
        } catch (error) {
          console.error('Error fetching data:', error);
          setLoading(false);
        }
      };
  
      fetchData();
    }, [selectedFilter]);
  
    const handleFilterChange = (filter) => {
      setSelectedFilter(filter);
    };
  
    const toggleCreateForm = () => {
      setShowCreateForm(!showCreateForm);
    };
  
    const toggleUpdateForm = () => {
      setShowUpdateForm(!showUpdateForm)
  
    }
  
    const handleCreateUserForm = async (nom, email, motDePasse, role) => {
      try {
        const result = await UsersService.createUser(nom, email, motDePasse, role);
        if (result) {
          setBooks([...books, result]);
          setShowCreateForm(false);
          console.log('User stored with success');
        } else {
          console.error('Storing failed');
        }
      } catch (error) {
        console.error('Server error:', error);
      }
    };
    
    const handleUpdateUserForm = async (id, nom, email, motDePasse, role) => {
      try {
        
        const response = await UsersService.updateUser(id, nom, email, motDePasse, role);
        if (response) {
          setBooks(
            books.map((book) => (book.id === id ? response : book)) 
          );
          setShowUpdateForm(false);
          console.log("User updated successfully");
        } else {
          console.error('User update failed');
        }
      } catch (error) {
        console.error("Server error:", error);
      }
    };
  
    const onDelete = async (book) => {
      try {
        const { id } = book;
        console.log(id);
        const response = await UsersService.deleteUser(id);
        if (response.success) {
          setBooks(books.filter((b) => b.id !== id));
          console.log('Deleted User successfully');
        } else {
          console.error('Error deleting user');
        }
      } catch (error) {
        console.error('Server error:', error);
      }
    };
  
    const onUpdate = async (book) => {  
      try {
        const {id} = book
        const response = await UsersService.getUser(id);
        setCurrentData(response)
        console.log(response)
        await toggleUpdateForm();
  
      } catch (error) {
        console.error('Error updating user:', error);
      }
    };
  
    const cancelCreateBookForm = async() => {
      setShowCreateForm(false)
    }
    
    const cancelUpdateBookForm = async() => {
      setShowUpdateForm(false)
    }
    
    return (
      <div className="container">
        <Navbar />
        <main className="main-content">
          <div className='container2'>
            <h2>User Page</h2>
            <button onClick={toggleCreateForm}>Create</button>
          </div>
          <div className='side-by-side'>
            <UsersNavBar handleFilterChange={handleFilterChange} />
            {loading ? <p>Loading...</p> : <Board data={books} onUpdate={onUpdate} onDelete={onDelete} toggleUpdateForm={toggleUpdateForm} />}
          </div>
          {showCreateForm && <div className="overlay"><CreateUserForm onSubmit={handleCreateUserForm} onCancel={cancelCreateBookForm}/></div>}
          {showUpdateForm && <div className='overlay'><UpdateUserForm onSubmit={handleUpdateUserForm} current_data={current_data} onCancel={cancelUpdateBookForm} ></UpdateUserForm></div>}
        </main>
      </div>
    );
}
export default UserPage;