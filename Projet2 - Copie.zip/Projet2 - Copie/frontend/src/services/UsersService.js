const jwtToken = localStorage.getItem("jwtToken")

async function getUsers() {
    try {
        const response = await fetch('http://localhost:5000/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({jwtToken})
        });

        if (response.ok) {
            const data = await response.json();
            return data;
        } else {
            const errorData = await response.json();
            console.error('Fetching data failed', errorData);
            return [];
        }
    } catch (error) {
        console.error('Error:', error);
        return [
            {
                "id": 2,
                "titre": "The Brothers Karamazov",
                "auteur": "Fyodor Dostoevsky",
                "anneePublication": null,
                "genre": "",
                "resume": "",
                "disponible": true
            },
            {
                "id": 3,
                "titre": "Man's Search for Meaning",
                "auteur": "Victor Frankl",
                "anneePublication": null,
                "genre": "",
                "resume": "",
                "disponible": true
            }
        ];
    }
}

async function createUser(nom, email, motDePasse, role) {
    try {
        role = (typeof role === 'undefined' || role.toLowerCase() !== 'administrateur') ? 'utilisateur' : role;
        const response = await fetch('http://localhost:5000/api/users/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nom, email, motDePasse, role, jwtToken})
        });

        if (response.ok) {
            const data = await response.json();
            console.log('User created with success');
            return data;
        } else {
            const errorData = await response.json();
            console.error('User creation failed', errorData.error);
            return { success: false, error: errorData.error };
        }
    } catch (error) {
        console.error('Error:', error);
        return { success: false, error: 'Network error' };
    }
}

async function updateUser(id, nom, email, motDePasse, role) {
    try {
        role = (typeof role === 'undefined' || role.toLowerCase() !== 'administrateur') ? 'utilisateur' : role;
        console.log("updateuserid:", id)
        const response = await fetch(`http://localhost:5000/api/users/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nom, email, motDePasse, role,jwtToken})
        });

        if (response) {
            const data = await response.json();
            console.log('User updated with success');
            return data;
        } else {
            const errorData = await response.json();
            console.error('User update failed', errorData.error);
            return { success: false, error: errorData.error };
        }
    } catch (error) {
        console.error('Error:', error);
        return { success: false, error: 'Network error' };
    }
}

async function deleteUser(id) {
    console.log("delete user")
    try {
        const response = await fetch(`http://localhost:5000/api/users/${id}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({jwtToken})
        });
        if (response.ok) {
            console.log('Service: User deleted successfully');
            return { success: true };
        } else {
            const errorData = await response.json();
            console.error('Error deleting user', errorData);
            return { success: false, error: errorData.error };
        }
    } catch (error) {
        console.error('Error:', error);
        return { success: false, error: 'Network error' };
    }
}

async function getUser(id){
    try {
        const response = await fetch(`http://localhost:5000/api/users/${id}`,{
            method:'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({jwtToken})
        })
        if(response.ok){
            const data = response.json()
            return data
        }else{
            console.error("error fetching book")
        }
    } catch (error) {
        console.error("server error")
    }
}

export default { getUsers, createUser, updateUser, deleteUser, getUser };
