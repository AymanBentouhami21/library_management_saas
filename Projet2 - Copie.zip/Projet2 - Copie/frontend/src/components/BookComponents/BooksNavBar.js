import React from 'react';
import '../../styles/BooksNavBar.css'; // Import your CSS file for styling

const BooksNavBar = ({ handleFilterChange }) => {
  return (
    <nav className="navigation-bar2">
      <div className="nav-row2">
        <a href="#" onClick={() => handleFilterChange('Author')}>Author</a>
      </div>
      <div className="nav-row2">
        <a href="#" onClick={() => handleFilterChange('Genre')}>Genre</a>
      </div>
      <div className="nav-row2">
        <a href="#" onClick={() => handleFilterChange('Title')}>Title</a>
      </div>
      <div className='nav-row2'>
        <a href="#" onClick={() => handleFilterChange('Date')}>Date</a>
      </div>
    </nav>
  );
};

export default BooksNavBar;
