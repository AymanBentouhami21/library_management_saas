import React, { useState } from 'react';

const Login = () => {
  
  // State variables for email and password
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Function to handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    // Call the login function with email and password
    handleLogin(email, password);
  };

  // Function to handle login
  const handleLogin = async (email, password) => {
    try {
      const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ "email":email, "motDePasse":password })
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Login successful! JWT token:', data.token);
        localStorage.setItem("jwtToken", data.token);
        
        // Here you can handle the successful login, such as redirecting to another page or storing the token in localStorage
      } else {
        const errorData = await response.json();
        console.error('Login failed:', errorData.error);
        // Here you can handle the login failure, such as displaying an error message to the user
      }
    } catch (error) {
      console.error('Error:', error);
      // Here you can handle network errors
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="text"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
