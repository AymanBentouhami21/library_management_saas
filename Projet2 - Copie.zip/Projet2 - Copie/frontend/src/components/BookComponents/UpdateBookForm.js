import React, {useState} from 'react';
import '../../styles/CreateBookForm.css';
const CreateBookForm = ({onSubmit, current_data,onCancel}) => {
  // Use the props to set the initial values of the form fields

  const initialValues = {
    titre: current_data?.titre || "",
    auteur: current_data?.auteur || "",
    anneePublication: current_data?.anneePublication || "",
    genre: current_data?.genre || "",
    resume: current_data?.resume || "",
  };

  const [formData, setFormData] = useState(initialValues);

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.id]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    onSubmit(current_data.id,formData.titre, formData.auteur, formData.anneePublication, formData.genre, formData.resume);
  };

  const handleCancel = (event) => {
    event.preventDefault()
    onCancel()
  };
    
    return (
    <form onSubmit={handleSubmit} className="form-container">
        <h2>
            Update Book:
        </h2>
        <label>
        Titre:
        <input 
            text="qsdq"
            type="text" 
            id="titre"
            value={formData.titre}
            onChange={handleChange}
        />
        </label>
        <label>
        Auteur:
        <input 
            type="text" 
            id="auteur"
            value={formData.auteur}
            onChange={handleChange}
        />
        </label>
        <label>
        Année de publication:
        <input 
            type="text" 
            id="anneePublication"
            value={formData.anneePublication}
            onChange={handleChange}
        />
        </label>
        <label>
        Genre:
        <input 
            type="text" 
            id="genre"
            value={formData.genre}
            onChange={handleChange}
        />
        </label>
        <label>
        Résumé:
        <textarea 
            value={formData.resume} 
            onChange={handleChange}
            id="resume">
        </textarea>
        </label>
        <div className='buttonContainer'>
            <button type="submit">Submit</button>
            <button type="submit" className='cancelButton' onClick={handleCancel}>cancel</button>
        </div>
    </form>
    );
};

export default CreateBookForm;
