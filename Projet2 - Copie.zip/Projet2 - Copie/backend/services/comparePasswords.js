const bcrypt = require('bcrypt');

// Function to compare the plain text password with the hashed password
async function comparePasswords(plainTextPassword, hashedPassword) {
  try {
    // Compare the provided plain text password with the hashed password
    const isMatch = await bcrypt.compare(plainTextPassword, hashedPassword);
    return isMatch;
  } catch (error) {
    console.error('Error comparing passwords:', error);
    return false; // Return false in case of an error
  }
}

module.exports = comparePasswords;