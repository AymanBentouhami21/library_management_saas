const bcrypt = require('bcrypt');
async function hashPassword(plainTextPassword) {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(plainTextPassword, saltRounds);
    return hashedPassword;
  }


module.exports=hashPassword;