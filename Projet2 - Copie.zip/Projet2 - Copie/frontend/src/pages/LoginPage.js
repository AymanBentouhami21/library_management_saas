import React from 'react';
import LoginForm from '../components/BookComponents/LoginForm';
import LoginService from '../services/LoginService'; // or AuthService
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  // Optional state for displaying error messages

    const navigate = useNavigate();

    const handleLogin = async (email, password) => {
    // Call LoginService to handle login logic
    const result = await LoginService.login(email, password);
        try {
            if (result.success) {
                // Handle successful login (e.g., redirect)
                localStorage.setItem('jwtToken', result.token);
                navigate("/home");
            } else {
                // Handle login failure (e.g., display error message)
            }
        } catch (error) {
            
        }
    };

    return (
    <div>
        
        <LoginForm onSubmit={handleLogin} />
    </div>
    );
};

export default LoginPage;
