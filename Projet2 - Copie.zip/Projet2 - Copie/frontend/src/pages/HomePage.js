import React from 'react';
import Navbar from '../components/BookComponents/NavBar';


const HomePage = () => {
    return (
      <div className="container">
        <Navbar /> {/* Use the Navbar component */}
        <main className="main-content">
          <h2>Home Page</h2>
          <p>This is the home page content. Feel free to edit and customize it.</p>
        </main>
      </div>
    );
  };
  
  export default HomePage;