import React, { useState } from 'react';

const CreatePretreForm = ({ onSubmit }) => {
  // Use the props to set the initial values of the form fields,
  // or use a default value (null)
  const [dateDeRetour, setDateDeRetour] = useState(null); // Or initial value from props

  const handleSubmit = (event) => {
    event.preventDefault();

    onSubmit({ dateDeRetour }); // Submit the entire date object
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="dateDeRetour">
        Date de retour:
        <input
          type="date"
          id="dateDeRetour"
          name="dateDeRetour"
          value={dateDeRetour}
          onChange={(e) => setDateDeRetour(e.target.value)}
        />
      </label>
      <button type="submit">Submit</button>
    </form>
  );
};

export default CreatePretreForm;
