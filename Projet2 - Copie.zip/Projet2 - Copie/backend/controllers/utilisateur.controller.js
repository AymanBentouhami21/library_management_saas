// utilisateur.controller.js
const Utilisateur = require('../models/utilisateur.model');
const authenticate = require('../middleware/authenticate');
const hashPassword = require('../services/hashPassword');
const comparePasswords = require('../services/comparePasswords')


const jwt = require('jsonwebtoken');

// Controller function to create a new user

async function createUser(req, res) {
  try {
    const { nom, email, motDePasse, role} = req.body;
    console.log("sdqsdqsd")

 
    if(motDePasse !== ""){
      const newUser = await Utilisateur.create({ nom, email, motDePasse, role });
      res.status(201).json(newUser);
    }else{
      res.status(404)
    }
    
    
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'An internal server error occurred' });
  }
}
/*

async function createUser(req, res) {
  try {
    const { nom, email, motDePasse, role, jwtToken} = req.body;
    const {isAuthorized,message} = await authenticate(jwtToken,"administrateur");
    if(isAuthorized === false){
      return res.status(403).json({message})
    }
    const hashedPassword = await hashPassword(motDePasse);
    console.log(hashedPassword)
    
    const newUser = await Utilisateur.create({ nom, email, motDePasse:hashedPassword, role });
    
    res.status(201).json(newUser);
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'An internal server error occurred' });
  }
}
*/

async function loginUser(req, res) {
  console.log("Login User")
  try {
    const { email, motDePasse } = req.body;
    console.log("email:",email)
    console.log("motDePasse",motDePasse)
    const user = await Utilisateur.findOne({ where: { email } });
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid email' });
    }

  
    

    // Compare password without encryption
    if (motDePasse !== user.motDePasse) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user.id, role: user.role }, process.env.JWT_SECRETKEY, { expiresIn: '1h' });
    
    res.status(200).json({ token });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ error: 'An internal server error occurred' });
  }
}


// Controller function to get a user by ID
async function getUserById(req, res) {
  try {
    const userId = req.params.id;
    const {jwtToken} = req.body;
    const {isAuthorized, message} = await authenticate(jwtToken,"utilisateur")
    if(isAuthorized === false){
      res.status(403).json({message})
    }

    const user = await Utilisateur.findByPk(userId);
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    res.json(user);
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'An internal server error occurred' });
  }
}

async function updateUser(req, res) {
    try {
      const { id } = req.params; // Get user ID from URL parameter
      const { nom, email, motDePasse, role,jwtToken } = req.body; // Get updated user data from request body

      const {isAuthorized, message} = await authenticate(jwtToken,"administrateur")
      if(isAuthorized === false){
        return res.status(403).json({message})
      }

      // Check if the user exists
      const user = await Utilisateur.findByPk(id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      // Update user attributes
      user.nom = nom;
      user.email = email;
      user.motDePasse = motDePasse;
      user.role = role;
  
      // Save the updated user to the database
      await user.save();
  
      // Respond with the updated user object
      res.json(user);
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  }

async function deleteUser(req, res) {
  try {
    const { id } = req.params;
    const {jwtToken} = req.body;

    const {isAuthorized, message} = await authenticate(jwtToken,"administrateur")
    if(isAuthorized === false){
      return res.status(403).json({message})
      
    }

    const user = await Utilisateur.findByPk(id);
    if (user) {
      await user.destroy();
      res.status(200).json({ message: 'User deleted successfully' });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ error: 'An internal server error occurred' });
  }
}

async function getAllUsers(req,res){
  try {
    const  {jwtToken} = req.body
    const {isAuthorized, message,role} = await authenticate(jwtToken,"utilisateur")
    if(isAuthorized === false){
      res.status(403).json({message})
    }
    console.log("role",role)
    if(role === "utilisateur"){
     
      const users = await Utilisateur.findAll(
        {
          attributes : {exclude:["motDePasse"]}
        }
      )
      return res.status(200).json(users)
    }else{
      const users = await Utilisateur.findAll(
        {
          attributes : {exclude:[]}
        }
      )
      
      return res.status(200).json(users)
    }
    
  } catch (error) {
    console.error("error fetching books:",error);
    res.status(500).json({error:"An internal server error occured."})
  }
}

// Export the controller functions
module.exports = { createUser, loginUser, getUserById, updateUser, deleteUser,getAllUsers };
