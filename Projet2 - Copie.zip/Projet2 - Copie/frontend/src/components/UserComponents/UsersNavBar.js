import React from 'react';
import '../../styles/BooksNavBar.css'; // Import your CSS file for styling

const UsersNavBar = ({ handleFilterChange }) => {
  return (
    
    <nav className="navigation-bar2">
        
      <div className="nav-row2">
        <a href="#" onClick={() => handleFilterChange('nom')}>Nom</a>
      </div>
      <div className="nav-row2">
        <a href="#" onClick={() => handleFilterChange('email')}>Email</a>
      </div>
      
    </nav>
  );
};

export default UsersNavBar;
