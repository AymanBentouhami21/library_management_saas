const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors')

const utilisateurRoutes = require('./routes/utilisateur.routes');
const livreRoutes = require("./routes/livre.routes");
const pretRoutes = require("./routes/prets.routes");
// Load environment variables from .env file
dotenv.config();

const sequelize = require('./config/db.config');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Mount routes
app.use('/', utilisateurRoutes);
app.use('/', livreRoutes);
app.use('/', pretRoutes)
// Test DB connection
sequelize.authenticate()
  .then(() => {
    console.log('Database connected successfully');
  })
  .catch(err => {
    console.error('Database connection failed', err);
    process.exit(1);
  });

// Routes
// You can import and use your routes here
// const bookRoutes = require('./routes/book.routes');
// app.use('/api/books', bookRoutes);

const PORT = process.env.PORT || 5000;


app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
