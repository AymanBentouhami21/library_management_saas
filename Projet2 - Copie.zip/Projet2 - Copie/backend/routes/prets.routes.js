const express = require("express");
const router = express.Router();


const {createPrets, getPretById, getAllPret, updatePretById, deletePret,getPretByUserId,deletePretByBookId} = require("../controllers/pret.controller")

router.get('/api/prets', getAllPret);
router.get("/api/prets/:id", getPretById);
router.post("/api/prets", createPrets);
router.put("/api/prets", updatePretById);
//router.delete("/api/prets", deletePret)
router.post("/api/prets/byUserId",getPretByUserId)
router.delete("/api/prets/deleteByBookId", deletePretByBookId)
module.exports = router;