const Pret = require('../models/pret.model');
const bcrypt = require('bcrypt');
const authenticate = require('../middleware/authenticate')

async function createPrets(req,res){
    try {
        var { dateRetour, idLivre, jwtToken} = req.body;
        const {isAuthorized,message,userId} = await authenticate(jwtToken, "utilisateur");
        console.log("CreatePret")
        if(isAuthorized === false){
            console.log("isAUthorized")
            return res.status(403).json({message:message})
        }
        const idUtilisateur = userId;

        console.log("date de retour:", dateRetour);
        console.log("date de retour:", dateRetour.dateDeRetour);
        const formattedDateRetour = dateRetour.dateDeRetour + " 00:00:00";
        const newPret = await Pret.create({dateRetour:formattedDateRetour,idUtilisateur,idLivre});
        console.log(newPret)
        res.status(201).json(newPret);
    } catch (error) {
        console.error("error creating user:", error);
        res.status(500).json({error:"internal server error occured"});
    }
}

async function getAllPret(req,res){
    try {
        const allPrets = await Pret.findAll()
        res.status(200).json(allPrets);
    } catch (error) {
        console.error("error fetching prets:", error);
        res.status(500).json({error:"An internal server error occured"});
    }
}

async function updatePretById(req,res){
    try {
        const idpret = req.params.id;
        const pret = await Pret.findByPK(idpret);
        const dateRetour = req.body;

        pret.dateRetour = dateRetour;
        await pret.save()
        res.json(pret)
    } catch (error) {
        console.error("error fetching prets:", error);
        res.status(500).json({error:"An internal server error occured"});
    }
}

async function getPretByUserId(req,res){
    try {
        const {jwtToken} = req.body
        const {isAuthorized,message,userId} = await authenticate(jwtToken, "utilisateur");

        if(!userId){
            return res.status(400).json({ message: 'Missing required parameter: idUtilisateur' });
        }

        if(isAuthorized == false){
            return res.status(403).json({message:message})
        }
        
        

        const prets = await Pret.findAll({ where: { idUtilisateur: userId } });
        if (!prets.length) {
            return res.status(404).json({ message: 'No prets found for the given idUtilisateur' });
          }

        res.status(201).json(prets);

    } catch (error) {
        console.error('Error fetching prets by idUtilisateur:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
}

async function getPretById(req,res){
    try {
        const idpret = req.params.id;
        const pret = await Pret.findByPk(idpret);
        if(!pret){
            return res.status(404).json({error:'Pret not found'});
        }
        res.json(pret);
        
    } catch (error) {
        console.error('Error fetching user:', error);
        res.status(500).json({ error: 'An internal server error occurred' });
    }
}


async function deletePret(req,res){
    try {
        const idPret = req.params.id;
        const pret = await Pret.findByPK(idPret);

        if(!pret){
            res.status(404).json({ error: 'pret not found' });
            return;
        }else{
            await pret.destroy();
            res.status(200).json({message:"Pret deleted succesfully"});
        }

        
    } catch (error) {
        console.error('Error fetching user:', error);
    res.status(500).json({ error: 'An internal server error occurred' });
    }
}

async function deletePretByBookId(req,res){
    try {
        
        const {idLivre,jwtToken} = req.body
        console.log("jwtToken;",jwtToken)
        const {isAuthorized,message,userId} = await authenticate(jwtToken, "utilisateur");
        if(isAuthorized == false){
            return res.status(403).json({message:message})
        }

        console.log(idLivre)
        console.log(userId)
        const deletedRow = await Pret.destroy({where:{
            idLivre:idLivre,
            idUtilisateur:userId
        }})

        if (deletedRow === 0) {
            return res.status(404).json({ message: "No matching row found or already deleted." });
        }

        return res.status(200).json({ message: "Row deleted successfully." });
    } catch (error) {
        console.error("Error deleting row:", error);
        return res.status(500).json({ message: "Internal server error." });
    }


    
}

module.exports = {createPrets, getPretById, getAllPret, updatePretById, deletePret,getPretByUserId,deletePretByBookId}