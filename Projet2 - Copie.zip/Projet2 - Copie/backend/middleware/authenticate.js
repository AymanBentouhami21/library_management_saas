const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();
// Replace with your actual secret key
const secretKey = process.env.JWT_SECRETKEY;

async function authenticate(jwtToken, role_required) {
  try {
    const decodedPayload = jwt.verify(jwtToken, secretKey);

    // Check if role claim exists (modify claim name if needed)
    if (!decodedPayload.role) {
      return {isAuthorized:false, message: "Access Denied: Invalid Token"}; // Unauthorized: Missing role claim
    } else {
        if(decodedPayload.role === "administrateur"){
          const role = decodedPayload.role
          console.log("authenticate", role)
          return {isAuthorized:true, message:"Acces Granted", userId:decodedPayload.userId,role}
        }else if(decodedPayload.role === role_required){
          const role = decodedPayload.role
          console.log("authenticate", role)
          return {isAuthorized:true, message:"Acces Granted", userId:decodedPayload.userId,role}
        }
        else{
          const role = decodedPayload.role
          console;log("authenticate", role)
          return {isAuthorized:false, message:"Access Denied: Insufficient Perlission", role:role};
        }
    }
  } catch (error) {
    console.error('Error verifying token:', error.message);
    return {isAuthorized:false, message:"Server error"}; // Unauthorized: Invalid token
  }
}

module.exports = authenticate;