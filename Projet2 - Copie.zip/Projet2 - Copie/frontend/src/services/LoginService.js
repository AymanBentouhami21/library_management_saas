async function login(email, motDePasse) {
    try {
      const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, motDePasse }), // Use object destructuring
      });
  
        if (response.ok) {
          const data = await response.json();
          console.log('Login successful! JWT token:', data.token);
          localStorage.setItem('jwtToken', data.token);
          return { success: true, token: data.token }; // Return login result
        } else {
          const errorData = await response.json();
          console.error('Login failed:', errorData.error);
          return { success: false, error: errorData.error }; // Return login error
        }
    } catch (error) {
      console.error('Error:', error);
      return { success: false, error: 'Network error' }; // Return generic error
    }
  }
  
  export default { login }; // Export the login function
  