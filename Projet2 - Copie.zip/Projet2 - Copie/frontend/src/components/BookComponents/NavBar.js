// Navbar.jsx
import React from 'react';
import { NavLink } from 'react-router-dom';
import '../../styles/Navbar.css'; // Import your CSS file for styling

const Navbar = () => {
  return (
    <div class="clearfix">
      <div className='navbarContainer'>
      <nav className="navigation-bar">
      <div className="nav-row">
        <NavLink exact to="/home" activeClassName="active">DashBoard</NavLink>
      </div>
      <div className="nav-row">
        <NavLink to="/book" activeClassName="active">Books</NavLink>
      </div>
      <div className="nav-row">
        <NavLink to="/user" activeClassName="active">Users</NavLink>
      </div>
      
    </nav>
    </div>
    </div>
    
    
  );
};

export default Navbar;
